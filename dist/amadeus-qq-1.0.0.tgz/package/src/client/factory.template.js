__CLIENT_LOGIC__

const MODE_LABELS = {
  observe: '只读观察',
  'safe-chat': '安全对话',
  enhanced: '增强对话',
  'autonomous-social': '自主社交（部分功能待实现）',
  'owner-agent': '所有者代理（Owner Agent，部分功能待实现）',
}

const RESERVED_MODE_NOTE = '部分功能需配置或尚未验证：通用 Shell、浏览器、GitHub 仍未实现；QZone 与 Owner 工作区属于可选能力，需要配置 Provider/专用目录并在对应模式显式授权，且尚未完成真实 QQ 验证。保存只记录策略，实际能力以下方每项生效状态为准。'

const CAPABILITY_LABELS = {
  'qq.read': '读取 QQ 消息',
  'qq.send': '发送 QQ 消息',
  'dsh.search': 'DSH 搜索',
  'qq.friends.read': '读取 QQ 好友目录',
  'qq.groups.read': '读取 QQ 群目录',
  'qq.media.read': 'QQ 媒体读取（图片/语音/文件/视频）',
  'qq.reaction.write': '表情回应 / 点赞',
  'qq.poke': '戳一戳',
  'qq.recall': '撤回消息',
  'qq.group.essence': '设置群精华',
  'qq.group.notice': '发布群公告',
  'qq.group.card': '修改群名片',
  'qq.group.ban': '禁言群成员',
  'qq.group.whole_ban': '全员禁言',
  'qq.group.kick': '移出群成员',
  'qq.group.name': '修改群名称',
  'qq.group.admin': '设置群管理员',
  'qq.group.special_title': '设置群头衔',
  'qq.profile.write': '修改账号资料',
  'qq.qzone.use': '使用 QQ 空间（发布/互动/读取）',
  'qq.qzone.read': '读取 QQ 空间（旧版）',
  'qq.qzone.publish': 'QQ 空间发布（旧版）',
  'qq.owner.workspace': 'Owner 工作区文件',
  'dsh.shell': 'DSH Shell（未实现）',
}

const CSS = `
[data-amadeus-qq]{--am-qq-accent:#2f5bea;box-sizing:border-box;max-width:100%;min-width:0;color:var(--dsw-alias-label-primary,#1f2329);font-size:13px;line-height:1.65;padding:0 0 24px}
[data-amadeus-qq] *{box-sizing:border-box}
[data-amadeus-qq] h2{margin:0;font-size:22px;line-height:1.3;font-weight:600}
[data-amadeus-qq] h3{margin:0 0 8px;font-size:15px;line-height:1.4;font-weight:600}
[data-amadeus-qq] p{margin:8px 0}
[data-amadeus-qq] small{display:block;opacity:.72;font-size:12px;line-height:1.55}
[data-amadeus-qq] button{font:inherit;border:1px solid var(--dsw-alias-border-secondary,#8c8c8c55);border-radius:9px;padding:7px 12px;background:var(--dsw-alias-bg-layer-2,#8c8c8c18);color:inherit;cursor:pointer;max-width:100%}
[data-amadeus-qq] button:disabled{opacity:.45;cursor:not-allowed}
[data-amadeus-qq] .topbar{display:flex;gap:12px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;margin-bottom:10px}
[data-amadeus-qq] .sub{opacity:.72;margin-top:2px}
[data-amadeus-qq] .chips{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}
[data-amadeus-qq] .chip{border:1px solid var(--dsw-alias-border-secondary,#8c8c8c55);border-radius:999px;padding:3px 10px;font-size:12px;background:var(--dsw-alias-bg-layer-2,#8c8c8c12)}
[data-amadeus-qq] .chip.ok{border-color:#3a9b5f88;color:#2f7d4c}
[data-amadeus-qq] .chip.warn{border-color:#d29b3a88;color:#9a6a12}
[data-amadeus-qq] .panel{border:1px solid var(--dsw-alias-border-secondary,#8c8c8c44);border-radius:12px;padding:14px;margin:12px 0;background:var(--dsw-alias-bg-layer-2,#8c8c8c0a)}
[data-amadeus-qq] .sceneRow{border:1px solid var(--dsw-alias-border-secondary,#8c8c8c33);border-radius:10px;padding:10px 12px;margin:8px 0}
[data-amadeus-qq] .sceneHead{display:flex;gap:8px;align-items:baseline;flex-wrap:wrap}
[data-amadeus-qq] .mono{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:12px;opacity:.85;word-break:break-all}
[data-amadeus-qq] .cap{display:flex;gap:8px;align-items:center;justify-content:space-between;padding:6px 0;border-top:1px dashed var(--dsw-alias-border-secondary,#8c8c8c33)}
[data-amadeus-qq] .cap:first-of-type{border-top:0}
[data-amadeus-qq] .message{border-radius:9px;padding:9px 11px;margin:10px 0}
[data-amadeus-qq] .message.error{border:1px solid #d9534f88;color:#b33934;background:#d9534f12}
[data-amadeus-qq] .message.success{border:1px solid #3a9b5f88;color:#2f7d4c;background:#3a9b5f12}
[data-amadeus-qq] .muted{opacity:.72}
[data-amadeus-qq] select{font:inherit;border:1px solid var(--dsw-alias-border-secondary,#8c8c8c55);border-radius:8px;padding:5px 8px;background:var(--dsw-alias-bg-layer-1,#fff);color:inherit;max-width:100%}
[data-amadeus-qq] select:disabled{opacity:.5}
[data-amadeus-qq] input{font:inherit;border:1px solid var(--dsw-alias-border-secondary,#8c8c8c55);border-radius:8px;padding:5px 8px;background:var(--dsw-alias-bg-layer-1,#fff);color:inherit;max-width:100%;min-width:200px}
[data-amadeus-qq] input:disabled{opacity:.5}
[data-amadeus-qq] .editorRow{display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;padding:8px 0;border-top:1px dashed var(--dsw-alias-border-secondary,#8c8c8c33)}
[data-amadeus-qq] .editorRow:first-of-type{border-top:0}
[data-amadeus-qq] .editorMain{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
[data-amadeus-qq] .actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:12px}
[data-amadeus-qq] .sceneRow.selected{border-color:var(--am-qq-accent);box-shadow:0 0 0 1px var(--am-qq-accent) inset}
[data-amadeus-qq] .sceneRow{cursor:pointer}
`

function formatTransport(status) {
  if (status === 'connected') return 'OneBot 已连接'
  if (status === 'disabled') return 'OneBot 连接已禁用'
  if (status === 'mock') return 'OneBot 模拟传输'
  return 'OneBot 连接状态未知'
}

function modeLabel(mode) {
  return MODE_LABELS[mode] || String(mode || '未设置')
}

function capabilityLabel(id) {
  return CAPABILITY_LABELS[id] || id
}

function formatDeliveryTime(value) {
  const ms = Number(value)
  if (!Number.isFinite(ms) || ms <= 0) return '时间未知'
  try {
    return new Date(ms).toLocaleString('zh-CN', { hour12: false })
  } catch {
    return '时间未知'
  }
}

function Panel() {
  const [data, setData] = React.useState(null)
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState(null)
  const [readOnly, setReadOnly] = React.useState(false)
  const [selectedKey, setSelectedKey] = React.useState('')
  const [draft, setDraft] = React.useState(null)
  const [busy, setBusy] = React.useState(false)
  const [conflict, setConflict] = React.useState(false)
  const [notice, setNotice] = React.useState('')
  const [selectionHint, setSelectionHint] = React.useState('')
  const [deliveryInputs, setDeliveryInputs] = React.useState({})
  const [resolvingId, setResolvingId] = React.useState('')
  const loadSeq = React.useRef(0)
  const draftRef = React.useRef(null)
  const selectedKeyRef = React.useRef('')
  draftRef.current = draft
  selectedKeyRef.current = selectedKey

  const load = React.useCallback(async (options) => {
    const forceSync = options?.forceSync === true
    const seq = ++loadSeq.current
    setLoading(true)
    setError(null)
    try {
      const next = await fetchScenes()
      if (seq !== loadSeq.current) return
      setData(next)
      setReadOnly(false)
      setSelectionHint('')
      const list = Array.isArray(next.scenes) ? next.scenes : []
      const entry = list.find(item => item.key === selectedKeyRef.current) || list[0] || null
      setSelectedKey(entry?.key ?? '')
      const previous = draftRef.current
      if (!entry) {
        setDraft(null)
        draftRef.current = null
        return
      }
      if (forceSync || !previous || previous.sceneKey !== entry.key) {
        const fresh = { ...draftFromEntry(entry), sceneKey: entry.key }
        setDraft(fresh)
        draftRef.current = fresh
        setConflict(false)
        return
      }
      if (isDraftDirty(entry, previous)) {
        if (revisionOf(entry) !== previous.expectedRevision) setConflict(true)
        return
      }
      const fresh = { ...draftFromEntry(entry), sceneKey: entry.key }
      setDraft(fresh)
      draftRef.current = fresh
      setConflict(false)
    } catch (failure) {
      if (seq !== loadSeq.current) return
      setError(failure)
      setReadOnly(requiresReadOnly(failure))
    } finally {
      if (seq === loadSeq.current) setLoading(false)
    }
  }, [])

  React.useEffect(() => {
    void load()
  }, [load])

  const scenes = Array.isArray(data?.scenes) ? data.scenes : []
  const health = data?.health ?? null
  const ownerWorkspace = data?.ownerWorkspace ?? { configured: false, writes: false, maxBytes: 0 }
  const workspaceSummary = ownerWorkspaceSummary(ownerWorkspace)
  const providersSummary = providerSummary(data?.providers)
  const selected = scenes.find(item => item.key === selectedKey) || null
  const dirty = selected && draft ? isDraftDirty(selected, draft) : false
  const validation = selected && draft ? validateDraft(selected, draft) : '未选择场景'
  const unresolved = Array.isArray(selected?.unresolvedDeliveries) ? selected.unresolvedDeliveries : []
  const modes = Array.isArray(data?.modes) && data.modes.length > 0 ? data.modes : MODE_IDS
  const disabled = busy || readOnly || conflict || !selected || !draft

  const selectScene = (entry) => {
    if (busy) {
      setSelectionHint('正在保存权限，请等待保存完成后再切换场景。')
      return
    }
    const selection = nextDraftForSelection(selected, draft, entry)
    if (selection.blocked) {
      setSelectionHint('当前场景有未保存的权限修改；请先保存或取消修改后再切换场景。')
      return
    }
    setSelectedKey(entry.key)
    setDraft(selection.draft)
    draftRef.current = selection.draft
    setConflict(false)
    setSelectionHint('')
    setNotice('')
    setError(null)
  }

  const changeMode = (mode) => {
    setDraft(previous => (previous ? { ...previous, mode } : previous))
    setNotice('')
  }

  const changeOverride = (capability, value) => {
    setDraft(previous => {
      if (!previous) return previous
      const overrides = { ...previous.overrides }
      if (value === 'inherit') delete overrides[capability]
      else overrides[capability] = value
      return { ...previous, overrides }
    })
    setNotice('')
  }

  const cancel = () => {
    if (conflict) {
      setConflict(false)
      setSelectionHint('')
      void load({ forceSync: true })
      return
    }
    if (!selected) return
    const fresh = { ...draftFromEntry(selected), sceneKey: selected.key }
    setDraft(fresh)
    draftRef.current = fresh
    setConflict(false)
    setSelectionHint('')
    setNotice('')
    setError(null)
  }

  const reloadLatest = () => {
    setConflict(false)
    setSelectionHint('')
    void load({ forceSync: true })
  }

  const save = async () => {
    if (!selected || !draft || validation || busy || readOnly || conflict) return
    setBusy(true)
    setSelectionHint('')
    setError(null)
    setNotice('')
    try {
      await savePermissions(selected, draft)
      await load({ forceSync: true })
      setNotice('已保存')
    } catch (failure) {
      if (failure.status === 409) {
        setConflict(true)
        setError(null)
      } else {
        setError(failure)
        if (requiresReadOnly(failure)) setReadOnly(true)
      }
    } finally {
      setBusy(false)
    }
  }

  const resolveDelivery = async (actionId) => {
    if (!selected || !draft || busy || readOnly || conflict || resolvingId) return
    const inputKey = deliveryInputKey(selected, actionId)
    if ((deliveryInputs[inputKey] ?? '') !== actionId) return
    setResolvingId(actionId)
    setError(null)
    setNotice('')
    try {
      await resolveUnknownDelivery(selected, actionId)
      setDeliveryInputs(previous => {
        const next = { ...previous }
        delete next[inputKey]
        return next
      })
      // Non-forced refresh keeps an unsaved permission draft intact.
      await load()
      setNotice('已将投递 ' + actionId + ' 标记为 failed')
    } catch (failure) {
      setError(failure)
      if (requiresReadOnly(failure)) setReadOnly(true)
    } finally {
      setResolvingId('')
    }
  }

  const sceneRow = (entry) => {
    const scene = entry.scene || {}
    const sceneId = String(scene.botId) + ':' + String(scene.peerId)
    const mode = entry.permissions?.mode ?? entry.effectiveMode
    const isSelected = entry.key === selectedKey
    return React.createElement(
      'div',
      {
        className: 'sceneRow' + (isSelected ? ' selected' : ''),
        key: entry.key || sceneId,
        role: 'button',
        tabIndex: 0,
        onClick: () => selectScene(entry),
        onKeyDown: (event) => { if (event.key === 'Enter' || event.key === ' ') selectScene(entry) },
      },
      React.createElement(
        'div',
        { className: 'sceneHead' },
        React.createElement('strong', null, scene.kind === 'group' ? '群聊' : '私聊'),
        React.createElement('span', { className: 'mono' }, sceneId),
        React.createElement('span', { className: 'chip' }, modeLabel(mode)),
        React.createElement('span', { className: 'chip' }, 'revision ' + revisionOf(entry)),
        React.createElement('span', { className: 'chip ' + (entry.health?.sessionActive ? 'ok' : 'warn') }, entry.health?.sessionActive ? 'Session 活跃' : '无活动 Session'),
        entry.ownerEligible ? React.createElement('span', { className: 'chip ok' }, '可信 Owner 私聊') : null,
      ),
    )
  }

  return React.createElement(
    'div',
    { 'data-amadeus-qq': 'true' },
    React.createElement('style', null, CSS),
    React.createElement(
      'div',
      { className: 'topbar' },
      React.createElement(
        'div',
        null,
        React.createElement('h2', null, 'Amadeus QQ'),
        React.createElement('div', { className: 'sub' }, 'QQ 场景权限。选择场景后可调整模式与能力覆盖；未实现或未配置的能力不会执行，实际能力以每项生效状态为准。'),
      ),
      React.createElement('button', { type: 'button', onClick: () => { void load() }, disabled: loading || busy }, loading ? '刷新中…' : '刷新'),
    ),
    React.createElement(
      'div',
      { className: 'chips' },
      React.createElement('span', { className: 'chip ' + (health?.enabled ? 'ok' : 'warn') }, health?.enabled ? '插件运行中' : '插件未运行'),
      React.createElement('span', { className: 'chip ' + (health?.transport === 'connected' ? 'ok' : 'warn') }, formatTransport(health?.transport)),
      React.createElement('span', { className: 'chip' }, '已见场景：' + (health?.scenes ?? scenes.length)),
      React.createElement('span', { className: 'chip' }, '活跃等待：' + (health?.activeWaits ?? 0)),
    ),
    React.createElement(
      'div',
      { className: 'panel' },
      React.createElement('h3', null, 'Owner 工作区'),
      React.createElement('small', null,
        '通用 Shell、浏览器、GitHub 工具未实现。Owner Agent 只提供受限的专用目录文件查看/写入；读取与写入都要求专用能力，写入还需逐次 Host 人工审批，审批不可用时拒绝。'),
      React.createElement(
        'div',
        { className: 'chips' },
        React.createElement('span', { className: 'chip ' + (ownerWorkspace.configured ? 'ok' : 'warn') },
          '状态：' + workspaceSummary.state),
        React.createElement('span', { className: 'chip' }, '权限：qq.owner.workspace（核心目录）'),
        React.createElement('span', { className: 'chip ' + (ownerWorkspace.writes ? 'warn' : 'ok') },
          '写入：' + workspaceSummary.writes),
        React.createElement('span', { className: 'chip warn' }, '实机未验证'),
        ownerWorkspace.configured
          ? React.createElement('span', { className: 'chip' }, '单文件上限 ' + workspaceSummary.maxBytes + ' 字节')
          : null,
      ),
      React.createElement('small', { className: 'muted' }, workspaceSummary.note),
    ),
    React.createElement(
      'div',
      { className: 'panel' },
      React.createElement('h3', null, '媒体发送与 QZone'),
      React.createElement('small', null,
        '这里只显示 Provider 状态，不显示目录路径、回环地址或令牌环境变量值。两项默认关闭。'),
      React.createElement(
        'div',
        { className: 'chips' },
        React.createElement('span', { className: 'chip warn' }, '媒体发送：' + providersSummary.mediaSend),
        React.createElement('span', { className: 'chip warn' }, 'QZone：' + providersSummary.qzone),
        React.createElement('span', { className: 'chip warn' }, '实机未验证'),
      ),
      React.createElement('small', { className: 'muted' },
        '状态来自当前 QQ preset 看到的实时工具清单；没有活动 QQ Session 时可能显示未观测到接线。权限允许与否见各能力行，实机投递/发布尚未验证。'),
    ),
    readOnly ? React.createElement('div', { className: 'message error' }, '此页面为只读：当前请求没有通过 DSH Owner 验证，或管理接口不可用。仅本机访问不等于管理员授权。') : null,
    error ? React.createElement('div', { className: 'message error', role: 'alert' }, '读取或保存失败：' + managementErrorMessage(error)) : null,
    notice ? React.createElement('div', { className: 'message success', role: 'status' }, notice) : null,
    selectionHint ? React.createElement('div', { className: 'message error', role: 'alert' }, selectionHint) : null,
    loading && !data ? React.createElement('p', { role: 'status' }, '正在读取 QQ 场景…') : null,
    !loading && !error && scenes.length === 0
      ? React.createElement('div', { className: 'panel' }, React.createElement('p', null, '暂无已见且在允许列表内的 QQ 场景。'), React.createElement('small', null, '场景只有在收到可信 QQ 事件后才会出现在这里。'))
      : null,
    scenes.length > 0
      ? React.createElement(
          'div',
          { className: 'panel' },
          React.createElement('h3', null, '已见场景'),
          React.createElement('small', null, '仅显示场景元数据与权限摘要；不包含聊天正文、凭据、令牌或真实文件路径。'),
          ...scenes.map(sceneRow),
        )
      : null,
    selected && draft
      ? React.createElement(
          'div',
          { className: 'panel' },
          React.createElement(
            'div',
            { className: 'sceneHead' },
            React.createElement('h3', null, '编辑权限'),
            React.createElement('span', { className: 'chip' }, 'revision ' + revisionOf(selected)),
            React.createElement('span', { className: 'chip ' + (dirty ? 'warn' : 'ok') }, dirty ? '有未保存修改' : '无未保存修改'),
          ),
          React.createElement('small', null, '保存时发送 expectedRevision；冲突不会被自动覆盖。'),
          conflict
            ? React.createElement(
                'div',
                { className: 'message error', role: 'alert' },
                '权限已被其他窗口修改（409）。请重新加载最新权限后再编辑；当前草稿不会自动覆盖。',
                React.createElement('div', { className: 'actions' }, React.createElement('button', { type: 'button', onClick: reloadLatest }, '重新加载最新权限')),
              )
            : null,
          validation ? React.createElement('div', { className: 'message error', role: 'alert' }, validation) : null,
          React.createElement(
            'div',
            { className: 'editorRow' },
            React.createElement(
              'div',
              { className: 'editorMain' },
              React.createElement('strong', null, '模式'),
              React.createElement('small', null, '五级模式只代表能力，不包含人格；群管理在 Safe Chat 默认包含（仍需机器人具备群权限），不需要 Owner Agent。'),
            ),
            React.createElement(
              'select',
              {
                value: draft.mode,
                disabled,
                'aria-label': '场景模式',
                onChange: (event) => changeMode(event.target.value),
              },
              ...modes.map(mode => React.createElement(
                'option',
                {
                  key: mode,
                  value: mode,
                  disabled: mode === 'owner-agent' && selected.ownerEligible !== true,
                },
                modeLabel(mode),
              )),
            ),
          ),
          draft.mode === 'owner-agent' || draft.mode === 'autonomous-social'
            ? React.createElement('small', { className: 'muted', role: 'note' }, RESERVED_MODE_NOTE)
            : null,
          ...(selected.capabilities ?? [])
            .filter(cap => cap.id !== 'qq.qzone.read' && cap.id !== 'qq.qzone.publish')
            .map(cap => {
            const hint = capabilityStateHint(cap)
            const configHint = capabilityConfigHint(cap, { ownerWorkspace, providers: data?.providers })
            return React.createElement(
            'div',
            { className: 'editorRow', key: cap.id },
            React.createElement(
              'div',
              { className: 'editorMain' },
              React.createElement('strong', null, capabilityLabel(cap.id)),
              React.createElement('small', null, cap.id),
              React.createElement('span', { className: 'chip ' + (cap.implemented ? 'ok' : 'warn') },
                cap.implemented ? '已实现' : '策略占位，尚不可执行'),
            ),
            React.createElement(
              'div',
              { className: 'editorMain' },
              React.createElement(
                'select',
                {
                  value: draft.overrides[cap.id] ?? 'inherit',
                  disabled,
                  'aria-label': capabilityLabel(cap.id) + ' 覆盖',
                  onChange: (event) => changeOverride(cap.id, event.target.value),
                },
                React.createElement('option', { value: 'inherit' }, 'inherit（继承模式）'),
                React.createElement('option', { value: 'allow' }, 'allow（显式允许）'),
                React.createElement('option', { value: 'deny' }, 'deny（显式拒绝）'),
              ),
              React.createElement(
                'span',
                { className: 'chip ' + (cap.implemented ? (cap.effective ? 'ok' : 'warn') : 'warn') },
                cap.implemented
                  ? (cap.effective ? '当前允许' : '当前拒绝') + (draft.overrides[cap.id] && draft.overrides[cap.id] !== cap.override ? '（保存后生效）' : '')
                  : '策略占位，尚不可执行',
              ),
              hint ? React.createElement('small', { className: 'muted' }, hint) : null,
              configHint ? React.createElement('small', { className: 'muted' }, configHint) : null,
            ),
          )}),
          React.createElement(
            'div',
            { className: 'actions' },
            React.createElement('button', { type: 'button', className: 'primary', onClick: save, disabled: disabled || !dirty || Boolean(validation) }, busy ? '保存中…' : '保存'),
            React.createElement('button', { type: 'button', onClick: cancel, disabled: busy || (!dirty && !conflict) }, '取消修改'),
          ),
          unresolved.length > 0
            ? React.createElement(
                'div',
                null,
                React.createElement('h3', null, '待人工对账的投递'),
                React.createElement('small', null, '以下 actionId 的发送结果未知（unknown）；本页不会自动重发。'),
                React.createElement('div', { className: 'message error', role: 'alert' },
                  '只有已在 QQ 平台确认未送达，才可标记失败；若实际已送达，后续手动重发可能重复。'),
                ...unresolved.map(delivery => {
                  const inputKey = deliveryInputKey(selected, delivery.actionId)
                  const typed = deliveryInputs[inputKey] ?? ''
                  const confirmed = typed === delivery.actionId
                  const submitting = resolvingId === delivery.actionId
                  return React.createElement(
                    'div',
                    { className: 'editorRow', key: delivery.actionId },
                    React.createElement(
                      'div',
                      { className: 'editorMain' },
                      React.createElement('strong', null, delivery.actionId),
                      React.createElement('span', { className: 'chip warn' }, 'unknown'),
                      React.createElement('small', { className: 'mono' }, formatDeliveryTime(delivery.updatedAt)),
                    ),
                    React.createElement(
                      'div',
                      { className: 'editorMain' },
                      React.createElement('input', {
                        type: 'text',
                        value: typed,
                        disabled: disabled || Boolean(resolvingId),
                        placeholder: '输入完整 actionId',
                        'aria-label': '确认 actionId ' + delivery.actionId,
                        autoComplete: 'off',
                        spellCheck: false,
                        onChange: (event) => setDeliveryInputs(previous => ({ ...previous, [inputKey]: event.target.value })),
                      }),
                      React.createElement('button', {
                        type: 'button',
                        onClick: () => { void resolveDelivery(delivery.actionId) },
                        disabled: disabled || Boolean(resolvingId) || !confirmed,
                      }, submitting ? '提交中…' : '标记为失败'),
                    ),
                  )
                }),
              )
            : null,
        )
      : null,
    React.createElement('small', { className: 'muted' }, '管理接口要求 DSH Owner admission 与同源请求；该页面不自行判断管理员身份。'),
  )
}

return {
  inject: ['slots'],
  apply(ctx) {
    let active
    const activate = () => {
      if (active) return active.dispose
      let dispose = () => {}
      try {
        dispose = ctx.slots.inject('settings.section', () => ctx.slots.register({
          name: 'settings.section',
          id: 'amadeus-qq',
          order: 30,
          label: () => 'Amadeus QQ',
        }, Panel)) || (() => {})
      } catch (error) {
        console.error('[amadeus-qq] settings.section unavailable', error)
      }
      const disposal = () => {
        if (!active || active.dispose !== disposal) return
        active = undefined
        try { dispose() } catch { /* already disposed */ }
      }
      active = { dispose: disposal }
      return disposal
    }
    if (typeof ctx.effect === 'function') ctx.effect(() => activate(), 'amadeus-qq: settings page')
    else activate()
  },
}
